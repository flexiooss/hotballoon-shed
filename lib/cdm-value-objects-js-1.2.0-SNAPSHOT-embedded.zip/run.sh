#!/bin/bash
java -cp "lib/*" org.codingmatters.value.objects.js.Main $@